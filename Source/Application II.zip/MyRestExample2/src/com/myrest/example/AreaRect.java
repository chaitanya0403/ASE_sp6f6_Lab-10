package com.myrest.example;
import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Path;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.MediaType;


import org.bson.Document;
import org.json.*;
//import com.ibm.json.java.JSON;
//import com.ibm.json.java.JSONObject;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.WriteResult;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.annotation.XmlRootElement;
@Path("/rectarea")
public class AreaRect {
 
	  @Path("create/{l}/{b}")
	  @GET
//	  @Produces("application/xml")
	  @Produces("text/plain")
	  public String rectangleareacreate(@PathParam("l") Double l, @PathParam("b") Double b){
		Double area;
		Double length = l;
		Double breadth =b;
		area =  (length * breadth);
		MongoClientURI uri = new MongoClientURI("mongodb://chaitu:parzival@ds019668.mlab.com:19668/assigndemo");
		MongoClient client = new MongoClient(uri);

		DB db = client.getDB(uri.getDatabase());
		DBCollection users = db.getCollection("areas");
		BasicDBObject doc = new BasicDBObject();
		doc.put("length", length);
		doc.put("breadth", breadth);
		doc.put("area", area);
		users.insert(doc);
		DBCursor cursor = users.find(doc);
		String ls = null;
		while (cursor.hasNext()) {
			ls = ((cursor.next()).toString());
		}			
//		String result = "@Produces(\"application/xml\") \n Area of Rectangle: " + area;
//		System.out.println("Inserted in Database");
//		return "<areaofrectangle>" + "<length>" + length + "</length>"+ "<breadth>" + breadth + "</breadth>" + "<area>" + result + "</area>" + "</areaofrectangle>";
		return "Data Created \n" + ls;
	  }

	  @Path("retrieve/{a}")
	  @GET
	  @Produces("text/plain")
//	  @Produces(MediaType.APPLICATION_JSON)
	  public String rectanglearearetrieve(@PathParam("a") Double a){
		    Double area = a;
			MongoClientURI uri = new MongoClientURI("mongodb://chaitu:parzival@ds019668.mlab.com:19668/assigndemo");
			MongoClient client = new MongoClient(uri);
			DB db = client.getDB(uri.getDatabase());
			DBCollection users = db.getCollection("areas");
			BasicDBObject doc = new BasicDBObject();
			doc.put("area", area);
			DBCursor cursor1 = users.find();
			while (cursor1.hasNext()) {
				System.out.println(cursor1.next());
			}			
			DBCursor cursor = users.find(doc);
			String ls = null;
			while (cursor.hasNext()) {
				ls = ((cursor.next()).toString());
			}			
			return "Data Retrieved \n" + ls;
	  }
	  @Path("update/{f}/{u}")
	  @GET
	  @Produces("text/plain")
	  public String rectangleareaupdate(@PathParam("f") Double f, @PathParam("u") Double u){
			MongoClientURI uri = new MongoClientURI("mongodb://chaitu:parzival@ds019668.mlab.com:19668/assigndemo");
			MongoClient client = new MongoClient(uri);
			DB db = client.getDB(uri.getDatabase());
			DBCollection users = db.getCollection("areas");
			BasicDBObject doc = new BasicDBObject();
			doc.put("area", f);
			DBCursor cursor1 = users.find(doc);
			String ls = null;
			while (cursor1.hasNext()) {
				ls = ((cursor1.next()).toString());
			}
			DBCursor testItemsCursor = users.find(doc);
			if(testItemsCursor.hasNext()) {
			    DBObject testCodeItem = testItemsCursor.next();
			    testCodeItem.put("area", u);
			    users.save(testCodeItem); }
			BasicDBObject doc1 = new BasicDBObject();
			doc1.put("area", u);
			DBCursor cursor = users.find(doc1);
			String ls1 = null;
			while (cursor.hasNext()) {
				ls1 = ((cursor.next()).toString());
			}			
			return "Database Updated \n Before Updation \n" + ls + "\n After Updation \n" + ls1;
			
	  }
	  @Path("delete/{d}")
	  @GET
	  @Produces("text/plain")
	  public String rectangleareadelete(@PathParam("d") Double d){

			MongoClientURI uri = new MongoClientURI("mongodb://chaitu:parzival@ds019668.mlab.com:19668/assigndemo");
			MongoClient client = new MongoClient(uri);

			DB db = client.getDB(uri.getDatabase());
			DBCollection users = db.getCollection("areas");
			BasicDBObject doc = new BasicDBObject();
			doc.put("area", d);
			DBCursor cursor = users.find(doc);
			while (cursor.hasNext()) {
			    DBObject item = cursor.next();
			    users.remove(item);
			}
			return "Selected item Deleted";
 }
}