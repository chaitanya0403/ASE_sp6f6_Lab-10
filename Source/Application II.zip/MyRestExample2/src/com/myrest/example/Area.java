package com.myrest.example;

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Path;

import org.bson.Document;
import org.json.*;
//import com.ibm.json.java.JSON;
//import com.ibm.json.java.JSONObject;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.WriteResult;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
 
@Path("/area")
public class Area {
	@GET
	@Produces("application/xml")
	public String areastatic() {
 
		Double area;
		Double side = 10.0;
		area = (side * side);
		MongoClientURI uri = new MongoClientURI("mongodb://chaitu:parzival@ds019668.mlab.com:19668/assigndemo");
		MongoClient client = new MongoClient(uri);

		DB db = client.getDB(uri.getDatabase());
		DBCollection users = db.getCollection("studentrecords");
		BasicDBObject doc = new BasicDBObject();
		doc.put("side", side);
		doc.put("area", area);
		users.insert(doc);
 
		String result = "@Produces(\"application/xml\") \n Area of square: " + area;
		return "<conversion>" + "<side>" + side + "</side>" + "<output>" + result + "</output>" + "</conversion>";
	}
 
	@Path("{c}")
	@GET
	@Produces("application/xml")
	public String areainput(@PathParam("c") Double c) {
		Double area;
		Double side = c;
		area = (side * side);
		MongoClientURI uri = new MongoClientURI("mongodb://chaitu:parzival@ds019668.mlab.com:19668/assigndemo");
		MongoClient client = new MongoClient(uri);
		DB db = client.getDB(uri.getDatabase());
		DBCollection users = db.getCollection("studentrecords");
		BasicDBObject doc = new BasicDBObject();
		doc.put("side", side);
		doc.put("area", area);
		users.insert(doc);

		String result = "@Produces(\"application/xml\") \n Area of Square: " + area;
		return "<conversion>" + "<side>" + side + "</side>" + "<output>" + result + "</output>" + "</conversion>";
	}
}