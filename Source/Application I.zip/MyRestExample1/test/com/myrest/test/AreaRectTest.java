package com.myrest.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class AreaRectTest {

	@Test
	public void test1() {
		AreaRect testcase = new AreaRect();
		String myresult = testcase.rectangleareainput(10.0, 5.0);
		Double testlength = 10.0;
		Double testbreadth = 5.0;
		Double ta = 50.0;
		String res = "@Produces(\"application/xml\") \n Area of Rectangle: " + ta;
		String results = "<areaofrectangle>" + "<length>" + testlength + "</length>"+ "<breadth>" + testbreadth + "</breadth>" + "<area>" + res + "</area>" + "</areaofrectangle>";
		System.out.println("@Test area(): " + results + " = " + myresult);
		assertEquals(results, myresult);
	}
	@Test
	public void test2()
	{
		AreaRect testcase2 = new AreaRect();
		String myresult2 = testcase2.rectangleareainput(20.0, 10.0);
		Double testlength2 = 20.0;
		Double testbreadth2 = 10.0;
		Double ta2 = 200.0;
		String res2 = "@Produces(\"application/xml\") \n Area of Rectangle: " + ta2;
		String results2 = "<areaofrectangle>" + "<length>" + testlength2 + "</length>"+ "<breadth>" + testbreadth2 + "</breadth>" + "<area>" + res2 + "</area>" + "</areaofrectangle>";
		System.out.println("@Test area(): " + results2 + " = " + myresult2);
		assertEquals(results2, myresult2);
	}

}