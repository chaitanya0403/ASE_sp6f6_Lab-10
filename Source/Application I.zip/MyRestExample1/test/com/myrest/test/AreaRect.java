package com.myrest.test;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
 
@Path("/rectarea")
public class AreaRect {
 
	  @GET
	  @Produces("application/xml")
	  public String rectanglearea() {
 
		Double length = 10.0;
		Double breadth = 5.0;
		Double area;
		area = (length * breadth); 
		String result = "@Produces(\"application/xml\") \n Area of Rectangle: " + area;
		return "<areaofrectangle>" + "<length>" + length + "</length>"+ "<breadth>" + breadth + "</breadth>" + "<area>" + result + "</area>" + "</areaofrectangle>";
	  }
 
	  @Path("/{l}/{b}")
	  @GET
	  @Produces("application/xml")
	  public String rectangleareainput(@PathParam("l") Double l, @PathParam("b") Double b){
		Double area;
		Double length = l;
		Double breadth =b;
		area =  (length * breadth); 
		String result = "@Produces(\"application/xml\") \n Area of Rectangle: " + area;
		return "<areaofrectangle>" + "<length>" + length + "</length>"+ "<breadth>" + breadth + "</breadth>" + "<area>" + result + "</area>" + "</areaofrectangle>";	  		
	  }
}